# gRPC

High-performance services using Go and gRPC

---

### Agenda

Intro (2m)  
What is gRPC? (2m)  
HTTP/1.1 vs HTTP/2.0 (4m)  
Protocol Buffers (4m)  
Development Demo (15-20m)  
Deployment Demo (10m)  
Questions (or ask them throughout)  
<div class="north-east">
<i class="fa fa-clock-o fa-3x" aria-hidden="true"> </i>
</div>
---

### What is gRPC?

gRPC stands for gRPC Remote Procedure Calls.  

gRPC uses an Interface Definition Language (IDL) to describe APIs (Protocol Buffers).  

Server/client stubs are generated from .proto file using Protocol Buffers compiler.  

Client/server communication using HTTP/2.  

---

### HTTP/1.1 vs HTTP/2

HTTP/1 allowed pipelining, but responses have to be processed in order.  

This leads to head-of-line blocking and requires client-server communications
to use many connections for better parallelism.

<div class="south">
<i class="fa fa-arrow-down fa-2x" aria-hidden="true"> </i>
</div>

+++

### HTTP/1.1 vs HTTP/2

HTTP/2 is a binary protocol and supports header compression.  

HTTP/2 allows for multiplexed streams. This allows concurrent
requests/responses to be processed asynchronously and independently
over a single TCP connection.

---

<span class='menu-title slide-title'>Sample .proto file</span>
```
syntax = "proto3";
package tutorial;

import "google/protobuf/timestamp.proto";

option java_package = "com.example.tutorial";
option java_outer_classname = "AddressBookProtos";

option csharp_namespace = "Google.Protobuf.Examples.AddressBook";

message Person {
  string name = 1;
  int32 id = 2;  
  string email = 3;

  enum PhoneType {
    MOBILE = 0;
    HOME = 1;
    WORK = 2;
  }

  message PhoneNumber {
    string number = 1;
    PhoneType type = 2;
  }

  repeated PhoneNumber phones = 4;

  google.protobuf.Timestamp last_updated = 5;
}

message AddressBook {
  repeated Person people = 1;
}

```


<span class="code-presenting-annotation fragment current-only" data-code-focus="1-9"></span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="11-30"></span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="12-14"></span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="27"></span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="29"></span>

---

### Why not just use XML?

Protocol buffers are:  

Simpler   
3-10 times smaller   
20-100 times faster  
Less ambiguous  

<div class="south">
<i class="fa fa-arrow-down fa-2x" aria-hidden="true"> </i>
</div>

<div class="east">
<i class="fa fa-thumbs-o-up fa-4x" aria-hidden="true"> </i>
</div>

+++

### Why not just use XML?

But protocol buffers are not:  

Human-readable  
Human-editable  
Self-describing

<div class="east">
<i class="fa fa-thumbs-o-down fa-4x" aria-hidden="true"> </i>
</div>

---

### Demo

#### Services

**phone-client** (user-facing service)  
**phone-client** (storage/retrieval service)  

#### Tasks

**client-v1** calls **server-v1** via REST/JSON.  
**client-v2** will call **server-v2** via gRPC.  

#### Deployment

Show v1/v2 deployment with Istio/k8s
---

### Questions

<div class="north-east">
<i class="fa fa-question fa-2x" aria-hidden="true"> </i>
</div>

<div class="east">
<i class="fa fa-comment fa-2x" aria-hidden="true"> </i>
</div>

<div class="south-east">
<i class="fa fa-trophy fa-2x" aria-hidden="true"> </i>
</div>